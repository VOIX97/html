print 0.977905
